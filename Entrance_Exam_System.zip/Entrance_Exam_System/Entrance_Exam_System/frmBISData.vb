﻿Public Class frmBISData
    Public BISdata As String = ""
    Private Sub frmBISData_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BasicInfoStudentData(BISdata)
    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub btnBISData_Click(sender As Object, e As EventArgs) Handles btnBISData.Click
        Me.Hide()

    End Sub
End Class