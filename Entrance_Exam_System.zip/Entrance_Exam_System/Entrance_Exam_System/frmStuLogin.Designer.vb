﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStuLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmStuLogin))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtStuUser = New System.Windows.Forms.TextBox()
        Me.btnStuLog = New System.Windows.Forms.Button()
        Me.txtStuPass = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.txtStuUser)
        Me.Panel1.Controls.Add(Me.btnStuLog)
        Me.Panel1.Controls.Add(Me.txtStuPass)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(301, 256)
        Me.Panel1.TabIndex = 5
        '
        'txtStuUser
        '
        Me.txtStuUser.Location = New System.Drawing.Point(37, 61)
        Me.txtStuUser.MaxLength = 43
        Me.txtStuUser.Name = "txtStuUser"
        Me.txtStuUser.Size = New System.Drawing.Size(244, 20)
        Me.txtStuUser.TabIndex = 6
        '
        'btnStuLog
        '
        Me.btnStuLog.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnStuLog.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnStuLog.Font = New System.Drawing.Font("Stencil", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStuLog.Location = New System.Drawing.Point(109, 168)
        Me.btnStuLog.Name = "btnStuLog"
        Me.btnStuLog.Size = New System.Drawing.Size(104, 68)
        Me.btnStuLog.TabIndex = 10
        Me.btnStuLog.Text = "Login Student"
        Me.btnStuLog.UseVisualStyleBackColor = False
        '
        'txtStuPass
        '
        Me.txtStuPass.Location = New System.Drawing.Point(37, 125)
        Me.txtStuPass.MaxLength = 8
        Me.txtStuPass.Name = "txtStuPass"
        Me.txtStuPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtStuPass.Size = New System.Drawing.Size(244, 20)
        Me.txtStuPass.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Stencil", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(98, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(121, 25)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Password"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Stencil", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(97, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 25)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Username"
        '
        'frmStuLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.CornflowerBlue
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(302, 256)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmStuLogin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtStuUser As System.Windows.Forms.TextBox
    Friend WithEvents btnStuLog As System.Windows.Forms.Button
    Friend WithEvents txtStuPass As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
