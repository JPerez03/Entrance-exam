﻿Public Class frmMaintenance
    Public strMAIN As String = ""
     

    Private Sub btnADDQUEST_Click(sender As Object, e As EventArgs) Handles btnADDQUEST.Click
        ADDQUESTION(strMAIN)
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked Then
            txtAns.Text = txtChc1.Text
        End If
    End Sub
 
    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked Then
            txtAns.Text = txtChc2.Text
        End If
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked Then
            txtAns.Text = txtChc3.Text
        End If
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        If RadioButton4.Checked Then
            txtAns.Text = txtChc4.Text
        End If
    End Sub
End Class