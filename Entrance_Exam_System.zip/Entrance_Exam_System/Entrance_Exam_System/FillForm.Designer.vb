﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FillForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FillForm))
        Me.btnSaveInfo = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtLN = New System.Windows.Forms.TextBox()
        Me.txtMN = New System.Windows.Forms.TextBox()
        Me.txtFN = New System.Windows.Forms.TextBox()
        Me.txtAdd = New System.Windows.Forms.TextBox()
        Me.cmbStuNational = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmbStuCS = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cmbStuGender = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtlrn = New System.Windows.Forms.TextBox()
        Me.txtStuCN = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtStuEmail = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtStuAge = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.txtUser = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtFatCN = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtFatEmail = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtFatAge = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtFatOccu = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.cmbFatGender = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmbFatCS = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.cmbFatNational = New System.Windows.Forms.ComboBox()
        Me.txtFatAdd = New System.Windows.Forms.TextBox()
        Me.txtFatFN = New System.Windows.Forms.TextBox()
        Me.txtFatMN = New System.Windows.Forms.TextBox()
        Me.txtFatLN = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtMothCN = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtMothEmail = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtMothAge = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtMothOccu = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.cmbMothGender = New System.Windows.Forms.ComboBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.cmbMothCS = New System.Windows.Forms.ComboBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.cmbMothNational = New System.Windows.Forms.ComboBox()
        Me.txtMothAdd = New System.Windows.Forms.TextBox()
        Me.txtMothFN = New System.Windows.Forms.TextBox()
        Me.txtMothMN = New System.Windows.Forms.TextBox()
        Me.txtMothLN = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.chckStuTOR = New System.Windows.Forms.CheckBox()
        Me.chckStuID = New System.Windows.Forms.CheckBox()
        Me.chckStuForm137 = New System.Windows.Forms.CheckBox()
        Me.chckStuNSO = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSaveInfo
        '
        Me.btnSaveInfo.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnSaveInfo.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSaveInfo.Font = New System.Drawing.Font("Stencil", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveInfo.Location = New System.Drawing.Point(1063, 668)
        Me.btnSaveInfo.Name = "btnSaveInfo"
        Me.btnSaveInfo.Size = New System.Drawing.Size(85, 61)
        Me.btnSaveInfo.TabIndex = 39
        Me.btnSaveInfo.Text = "Save"
        Me.btnSaveInfo.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(403, 69)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(58, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Last Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(319, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Middle Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(20, 116)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Address"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(19, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "First Name"
        '
        'txtLN
        '
        Me.txtLN.Location = New System.Drawing.Point(406, 89)
        Me.txtLN.Name = "txtLN"
        Me.txtLN.Size = New System.Drawing.Size(167, 20)
        Me.txtLN.TabIndex = 3
        '
        'txtMN
        '
        Me.txtMN.Location = New System.Drawing.Point(322, 89)
        Me.txtMN.Name = "txtMN"
        Me.txtMN.Size = New System.Drawing.Size(29, 20)
        Me.txtMN.TabIndex = 2
        '
        'txtFN
        '
        Me.txtFN.Location = New System.Drawing.Point(22, 89)
        Me.txtFN.Name = "txtFN"
        Me.txtFN.Size = New System.Drawing.Size(284, 20)
        Me.txtFN.TabIndex = 1
        '
        'txtAdd
        '
        Me.txtAdd.Location = New System.Drawing.Point(22, 135)
        Me.txtAdd.Name = "txtAdd"
        Me.txtAdd.Size = New System.Drawing.Size(550, 20)
        Me.txtAdd.TabIndex = 4
        '
        'cmbStuNational
        '
        Me.cmbStuNational.FormattingEnabled = True
        Me.cmbStuNational.Location = New System.Drawing.Point(22, 226)
        Me.cmbStuNational.Name = "cmbStuNational"
        Me.cmbStuNational.Size = New System.Drawing.Size(188, 21)
        Me.cmbStuNational.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(20, 206)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 13)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Nationality"
        '
        'cmbStuCS
        '
        Me.cmbStuCS.FormattingEnabled = True
        Me.cmbStuCS.Items.AddRange(New Object() {"Single", "In a relationship", "Engaged", "Married", "Its complicated", "In an open relationship", "Widowed", "Separated", "Divorced", "In a civil union", "In a domestic partnership"})
        Me.cmbStuCS.Location = New System.Drawing.Point(216, 226)
        Me.cmbStuCS.Name = "cmbStuCS"
        Me.cmbStuCS.Size = New System.Drawing.Size(171, 21)
        Me.cmbStuCS.TabIndex = 9
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(214, 206)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Civil Status"
        '
        'cmbStuGender
        '
        Me.cmbStuGender.FormattingEnabled = True
        Me.cmbStuGender.Items.AddRange(New Object() {"Male", "Female"})
        Me.cmbStuGender.Location = New System.Drawing.Point(393, 226)
        Me.cmbStuGender.Name = "cmbStuGender"
        Me.cmbStuGender.Size = New System.Drawing.Size(179, 21)
        Me.cmbStuGender.TabIndex = 10
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(391, 206)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(42, 13)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Gender"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.txtlrn)
        Me.GroupBox1.Controls.Add(Me.txtStuCN)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.txtStuEmail)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.txtStuAge)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.cmbStuGender)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.cmbStuCS)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.cmbStuNational)
        Me.GroupBox1.Controls.Add(Me.txtAdd)
        Me.GroupBox1.Controls.Add(Me.txtFN)
        Me.GroupBox1.Controls.Add(Me.txtMN)
        Me.GroupBox1.Controls.Add(Me.txtLN)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 17)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(583, 264)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Personal Information"
        '
        'txtlrn
        '
        Me.txtlrn.Enabled = False
        Me.txtlrn.Location = New System.Drawing.Point(28, 41)
        Me.txtlrn.Name = "txtlrn"
        Me.txtlrn.Size = New System.Drawing.Size(100, 20)
        Me.txtlrn.TabIndex = 21
        Me.txtlrn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtStuCN
        '
        Me.txtStuCN.Location = New System.Drawing.Point(363, 181)
        Me.txtStuCN.Name = "txtStuCN"
        Me.txtStuCN.Size = New System.Drawing.Size(209, 20)
        Me.txtStuCN.TabIndex = 7
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(360, 161)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(84, 13)
        Me.Label20.TabIndex = 20
        Me.Label20.Text = "Contact Number"
        '
        'txtStuEmail
        '
        Me.txtStuEmail.Location = New System.Drawing.Point(139, 181)
        Me.txtStuEmail.Name = "txtStuEmail"
        Me.txtStuEmail.Size = New System.Drawing.Size(209, 20)
        Me.txtStuEmail.TabIndex = 6
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(136, 161)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(32, 13)
        Me.Label19.TabIndex = 18
        Me.Label19.Text = "Email"
        '
        'txtStuAge
        '
        Me.txtStuAge.Location = New System.Drawing.Point(23, 181)
        Me.txtStuAge.Name = "txtStuAge"
        Me.txtStuAge.Size = New System.Drawing.Size(75, 20)
        Me.txtStuAge.TabIndex = 5
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(20, 161)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(26, 13)
        Me.Label18.TabIndex = 16
        Me.Label18.Text = "Age"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(114, 84)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Username"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(114, 148)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Password"
        '
        'txtPass
        '
        Me.txtPass.Location = New System.Drawing.Point(27, 111)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPass.Size = New System.Drawing.Size(237, 20)
        Me.txtPass.TabIndex = 12
        '
        'txtUser
        '
        Me.txtUser.Location = New System.Drawing.Point(27, 50)
        Me.txtUser.Name = "txtUser"
        Me.txtUser.Size = New System.Drawing.Size(237, 20)
        Me.txtUser.TabIndex = 11
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.txtUser)
        Me.GroupBox2.Controls.Add(Me.txtPass)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(617, 17)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(291, 209)
        Me.GroupBox2.TabIndex = 14
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Account Information"
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox4.Controls.Add(Me.txtFatCN)
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Controls.Add(Me.txtFatEmail)
        Me.GroupBox4.Controls.Add(Me.Label22)
        Me.GroupBox4.Controls.Add(Me.txtFatAge)
        Me.GroupBox4.Controls.Add(Me.Label23)
        Me.GroupBox4.Controls.Add(Me.txtFatOccu)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.cmbFatGender)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.cmbFatCS)
        Me.GroupBox4.Controls.Add(Me.Label12)
        Me.GroupBox4.Controls.Add(Me.cmbFatNational)
        Me.GroupBox4.Controls.Add(Me.txtFatAdd)
        Me.GroupBox4.Controls.Add(Me.txtFatFN)
        Me.GroupBox4.Controls.Add(Me.txtFatMN)
        Me.GroupBox4.Controls.Add(Me.txtFatLN)
        Me.GroupBox4.Controls.Add(Me.Label13)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Location = New System.Drawing.Point(28, 34)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(598, 278)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Father Information"
        '
        'txtFatCN
        '
        Me.txtFatCN.Location = New System.Drawing.Point(365, 151)
        Me.txtFatCN.Name = "txtFatCN"
        Me.txtFatCN.Size = New System.Drawing.Size(209, 20)
        Me.txtFatCN.TabIndex = 23
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(362, 131)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(84, 13)
        Me.Label21.TabIndex = 36
        Me.Label21.Text = "Contact Number"
        '
        'txtFatEmail
        '
        Me.txtFatEmail.Location = New System.Drawing.Point(141, 151)
        Me.txtFatEmail.Name = "txtFatEmail"
        Me.txtFatEmail.Size = New System.Drawing.Size(209, 20)
        Me.txtFatEmail.TabIndex = 22
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(138, 131)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(32, 13)
        Me.Label22.TabIndex = 34
        Me.Label22.Text = "Email"
        '
        'txtFatAge
        '
        Me.txtFatAge.Location = New System.Drawing.Point(25, 151)
        Me.txtFatAge.Name = "txtFatAge"
        Me.txtFatAge.Size = New System.Drawing.Size(75, 20)
        Me.txtFatAge.TabIndex = 21
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(22, 131)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(26, 13)
        Me.Label23.TabIndex = 32
        Me.Label23.Text = "Age"
        '
        'txtFatOccu
        '
        Me.txtFatOccu.Location = New System.Drawing.Point(24, 241)
        Me.txtFatOccu.Name = "txtFatOccu"
        Me.txtFatOccu.Size = New System.Drawing.Size(550, 20)
        Me.txtFatOccu.TabIndex = 27
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(23, 222)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(62, 13)
        Me.Label17.TabIndex = 30
        Me.Label17.Text = "Occupation"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(393, 175)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(42, 13)
        Me.Label10.TabIndex = 28
        Me.Label10.Text = "Gender"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbFatGender
        '
        Me.cmbFatGender.FormattingEnabled = True
        Me.cmbFatGender.Items.AddRange(New Object() {"Male", "Female"})
        Me.cmbFatGender.Location = New System.Drawing.Point(395, 195)
        Me.cmbFatGender.Name = "cmbFatGender"
        Me.cmbFatGender.Size = New System.Drawing.Size(179, 21)
        Me.cmbFatGender.TabIndex = 26
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(216, 175)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(59, 13)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "Civil Status"
        '
        'cmbFatCS
        '
        Me.cmbFatCS.FormattingEnabled = True
        Me.cmbFatCS.Items.AddRange(New Object() {"Single", "In a relationship", "Engaged", "Married", "Its complicated", "In an open relationship", "Widowed", "Separated", "Divorced", "In a civil union", "In a domestic partnership"})
        Me.cmbFatCS.Location = New System.Drawing.Point(218, 195)
        Me.cmbFatCS.Name = "cmbFatCS"
        Me.cmbFatCS.Size = New System.Drawing.Size(171, 21)
        Me.cmbFatCS.TabIndex = 25
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(22, 175)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(56, 13)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Nationality"
        '
        'cmbFatNational
        '
        Me.cmbFatNational.FormattingEnabled = True
        Me.cmbFatNational.Location = New System.Drawing.Point(24, 195)
        Me.cmbFatNational.Name = "cmbFatNational"
        Me.cmbFatNational.Size = New System.Drawing.Size(188, 21)
        Me.cmbFatNational.TabIndex = 24
        '
        'txtFatAdd
        '
        Me.txtFatAdd.Location = New System.Drawing.Point(21, 105)
        Me.txtFatAdd.Name = "txtFatAdd"
        Me.txtFatAdd.Size = New System.Drawing.Size(550, 20)
        Me.txtFatAdd.TabIndex = 20
        '
        'txtFatFN
        '
        Me.txtFatFN.Location = New System.Drawing.Point(22, 57)
        Me.txtFatFN.Name = "txtFatFN"
        Me.txtFatFN.Size = New System.Drawing.Size(284, 20)
        Me.txtFatFN.TabIndex = 17
        '
        'txtFatMN
        '
        Me.txtFatMN.Location = New System.Drawing.Point(322, 57)
        Me.txtFatMN.Name = "txtFatMN"
        Me.txtFatMN.Size = New System.Drawing.Size(29, 20)
        Me.txtFatMN.TabIndex = 18
        '
        'txtFatLN
        '
        Me.txtFatLN.Location = New System.Drawing.Point(406, 57)
        Me.txtFatLN.Name = "txtFatLN"
        Me.txtFatLN.Size = New System.Drawing.Size(167, 20)
        Me.txtFatLN.TabIndex = 19
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(19, 37)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(57, 13)
        Me.Label13.TabIndex = 19
        Me.Label13.Text = "First Name"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(20, 84)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(45, 13)
        Me.Label14.TabIndex = 22
        Me.Label14.Text = "Address"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(319, 37)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(69, 13)
        Me.Label15.TabIndex = 20
        Me.Label15.Text = "Middle Name"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(403, 37)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(58, 13)
        Me.Label16.TabIndex = 21
        Me.Label16.Text = "Last Name"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.GroupBox5)
        Me.GroupBox3.Controls.Add(Me.GroupBox4)
        Me.GroupBox3.Location = New System.Drawing.Point(16, 305)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(1255, 325)
        Me.GroupBox3.TabIndex = 15
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Parents Information"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.txtMothCN)
        Me.GroupBox5.Controls.Add(Me.Label24)
        Me.GroupBox5.Controls.Add(Me.txtMothEmail)
        Me.GroupBox5.Controls.Add(Me.Label25)
        Me.GroupBox5.Controls.Add(Me.txtMothAge)
        Me.GroupBox5.Controls.Add(Me.Label26)
        Me.GroupBox5.Controls.Add(Me.txtMothOccu)
        Me.GroupBox5.Controls.Add(Me.Label27)
        Me.GroupBox5.Controls.Add(Me.Label28)
        Me.GroupBox5.Controls.Add(Me.cmbMothGender)
        Me.GroupBox5.Controls.Add(Me.Label29)
        Me.GroupBox5.Controls.Add(Me.cmbMothCS)
        Me.GroupBox5.Controls.Add(Me.Label30)
        Me.GroupBox5.Controls.Add(Me.cmbMothNational)
        Me.GroupBox5.Controls.Add(Me.txtMothAdd)
        Me.GroupBox5.Controls.Add(Me.txtMothFN)
        Me.GroupBox5.Controls.Add(Me.txtMothMN)
        Me.GroupBox5.Controls.Add(Me.txtMothLN)
        Me.GroupBox5.Controls.Add(Me.Label31)
        Me.GroupBox5.Controls.Add(Me.Label32)
        Me.GroupBox5.Controls.Add(Me.Label33)
        Me.GroupBox5.Controls.Add(Me.Label34)
        Me.GroupBox5.Location = New System.Drawing.Point(651, 34)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(598, 278)
        Me.GroupBox5.TabIndex = 1
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Mother Information"
        '
        'txtMothCN
        '
        Me.txtMothCN.Location = New System.Drawing.Point(365, 151)
        Me.txtMothCN.Name = "txtMothCN"
        Me.txtMothCN.Size = New System.Drawing.Size(209, 20)
        Me.txtMothCN.TabIndex = 34
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(362, 131)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(84, 13)
        Me.Label24.TabIndex = 36
        Me.Label24.Text = "Contact Number"
        '
        'txtMothEmail
        '
        Me.txtMothEmail.Location = New System.Drawing.Point(141, 151)
        Me.txtMothEmail.Name = "txtMothEmail"
        Me.txtMothEmail.Size = New System.Drawing.Size(209, 20)
        Me.txtMothEmail.TabIndex = 33
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(138, 131)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(32, 13)
        Me.Label25.TabIndex = 34
        Me.Label25.Text = "Email"
        '
        'txtMothAge
        '
        Me.txtMothAge.Location = New System.Drawing.Point(25, 151)
        Me.txtMothAge.Name = "txtMothAge"
        Me.txtMothAge.Size = New System.Drawing.Size(75, 20)
        Me.txtMothAge.TabIndex = 32
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(22, 131)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(26, 13)
        Me.Label26.TabIndex = 32
        Me.Label26.Text = "Age"
        '
        'txtMothOccu
        '
        Me.txtMothOccu.Location = New System.Drawing.Point(24, 241)
        Me.txtMothOccu.Name = "txtMothOccu"
        Me.txtMothOccu.Size = New System.Drawing.Size(550, 20)
        Me.txtMothOccu.TabIndex = 38
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(23, 222)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(62, 13)
        Me.Label27.TabIndex = 30
        Me.Label27.Text = "Occupation"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(393, 175)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(42, 13)
        Me.Label28.TabIndex = 28
        Me.Label28.Text = "Gender"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbMothGender
        '
        Me.cmbMothGender.FormattingEnabled = True
        Me.cmbMothGender.Items.AddRange(New Object() {"Male", "Female"})
        Me.cmbMothGender.Location = New System.Drawing.Point(395, 195)
        Me.cmbMothGender.Name = "cmbMothGender"
        Me.cmbMothGender.Size = New System.Drawing.Size(179, 21)
        Me.cmbMothGender.TabIndex = 37
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(216, 175)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(59, 13)
        Me.Label29.TabIndex = 26
        Me.Label29.Text = "Civil Status"
        '
        'cmbMothCS
        '
        Me.cmbMothCS.FormattingEnabled = True
        Me.cmbMothCS.Items.AddRange(New Object() {"Single", "In a relationship", "Engaged", "Married", "Its complicated", "In an open relationship", "Widowed", "Separated", "Divorced", "In a civil union", "In a domestic partnership"})
        Me.cmbMothCS.Location = New System.Drawing.Point(218, 195)
        Me.cmbMothCS.Name = "cmbMothCS"
        Me.cmbMothCS.Size = New System.Drawing.Size(171, 21)
        Me.cmbMothCS.TabIndex = 36
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(22, 175)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(56, 13)
        Me.Label30.TabIndex = 24
        Me.Label30.Text = "Nationality"
        '
        'cmbMothNational
        '
        Me.cmbMothNational.FormattingEnabled = True
        Me.cmbMothNational.Location = New System.Drawing.Point(24, 195)
        Me.cmbMothNational.Name = "cmbMothNational"
        Me.cmbMothNational.Size = New System.Drawing.Size(188, 21)
        Me.cmbMothNational.TabIndex = 35
        '
        'txtMothAdd
        '
        Me.txtMothAdd.Location = New System.Drawing.Point(21, 105)
        Me.txtMothAdd.Name = "txtMothAdd"
        Me.txtMothAdd.Size = New System.Drawing.Size(550, 20)
        Me.txtMothAdd.TabIndex = 31
        '
        'txtMothFN
        '
        Me.txtMothFN.Location = New System.Drawing.Point(22, 57)
        Me.txtMothFN.Name = "txtMothFN"
        Me.txtMothFN.Size = New System.Drawing.Size(284, 20)
        Me.txtMothFN.TabIndex = 28
        '
        'txtMothMN
        '
        Me.txtMothMN.Location = New System.Drawing.Point(322, 57)
        Me.txtMothMN.Name = "txtMothMN"
        Me.txtMothMN.Size = New System.Drawing.Size(29, 20)
        Me.txtMothMN.TabIndex = 29
        '
        'txtMothLN
        '
        Me.txtMothLN.Location = New System.Drawing.Point(406, 57)
        Me.txtMothLN.Name = "txtMothLN"
        Me.txtMothLN.Size = New System.Drawing.Size(167, 20)
        Me.txtMothLN.TabIndex = 30
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(19, 37)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(57, 13)
        Me.Label31.TabIndex = 19
        Me.Label31.Text = "First Name"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(20, 84)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(45, 13)
        Me.Label32.TabIndex = 22
        Me.Label32.Text = "Address"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(319, 37)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(69, 13)
        Me.Label33.TabIndex = 20
        Me.Label33.Text = "Middle Name"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(403, 37)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(58, 13)
        Me.Label34.TabIndex = 21
        Me.Label34.Text = "Last Name"
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox6.Controls.Add(Me.chckStuTOR)
        Me.GroupBox6.Controls.Add(Me.chckStuID)
        Me.GroupBox6.Controls.Add(Me.chckStuForm137)
        Me.GroupBox6.Controls.Add(Me.chckStuNSO)
        Me.GroupBox6.Location = New System.Drawing.Point(931, 18)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(340, 209)
        Me.GroupBox6.TabIndex = 16
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Requirements Information"
        '
        'chckStuTOR
        '
        Me.chckStuTOR.AutoSize = True
        Me.chckStuTOR.Location = New System.Drawing.Point(31, 113)
        Me.chckStuTOR.Name = "chckStuTOR"
        Me.chckStuTOR.Size = New System.Drawing.Size(49, 17)
        Me.chckStuTOR.TabIndex = 16
        Me.chckStuTOR.Text = "TOR"
        Me.chckStuTOR.UseVisualStyleBackColor = True
        '
        'chckStuID
        '
        Me.chckStuID.AutoSize = True
        Me.chckStuID.Location = New System.Drawing.Point(31, 90)
        Me.chckStuID.Name = "chckStuID"
        Me.chckStuID.Size = New System.Drawing.Size(60, 17)
        Me.chckStuID.TabIndex = 15
        Me.chckStuID.Text = "ID 1x1 "
        Me.chckStuID.UseVisualStyleBackColor = True
        '
        'chckStuForm137
        '
        Me.chckStuForm137.AutoSize = True
        Me.chckStuForm137.Location = New System.Drawing.Point(31, 67)
        Me.chckStuForm137.Name = "chckStuForm137"
        Me.chckStuForm137.Size = New System.Drawing.Size(70, 17)
        Me.chckStuForm137.TabIndex = 14
        Me.chckStuForm137.Text = "Form 137"
        Me.chckStuForm137.UseVisualStyleBackColor = True
        '
        'chckStuNSO
        '
        Me.chckStuNSO.AutoSize = True
        Me.chckStuNSO.Location = New System.Drawing.Point(31, 43)
        Me.chckStuNSO.Name = "chckStuNSO"
        Me.chckStuNSO.Size = New System.Drawing.Size(55, 17)
        Me.chckStuNSO.TabIndex = 13
        Me.chckStuNSO.Text = "N.S.O"
        Me.chckStuNSO.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Stencil", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(1186, 668)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(85, 61)
        Me.Button1.TabIndex = 40
        Me.Button1.Text = "Back"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'FillForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.CornflowerBlue
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1298, 741)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnSaveInfo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "FillForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSaveInfo As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtLN As System.Windows.Forms.TextBox
    Friend WithEvents txtMN As System.Windows.Forms.TextBox
    Friend WithEvents txtFN As System.Windows.Forms.TextBox
    Friend WithEvents txtAdd As System.Windows.Forms.TextBox
    Friend WithEvents cmbStuNational As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmbStuCS As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cmbStuGender As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtStuCN As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtStuEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtStuAge As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtPass As System.Windows.Forms.TextBox
    Friend WithEvents txtUser As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtFatCN As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtFatEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtFatAge As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtFatOccu As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cmbFatGender As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents cmbFatCS As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents cmbFatNational As System.Windows.Forms.ComboBox
    Friend WithEvents txtFatAdd As System.Windows.Forms.TextBox
    Friend WithEvents txtFatFN As System.Windows.Forms.TextBox
    Friend WithEvents txtFatMN As System.Windows.Forms.TextBox
    Friend WithEvents txtFatLN As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents txtMothCN As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtMothEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtMothAge As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtMothOccu As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents cmbMothGender As System.Windows.Forms.ComboBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents cmbMothCS As System.Windows.Forms.ComboBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents cmbMothNational As System.Windows.Forms.ComboBox
    Friend WithEvents txtMothAdd As System.Windows.Forms.TextBox
    Friend WithEvents txtMothFN As System.Windows.Forms.TextBox
    Friend WithEvents txtMothMN As System.Windows.Forms.TextBox
    Friend WithEvents txtMothLN As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents chckStuTOR As System.Windows.Forms.CheckBox
    Friend WithEvents chckStuID As System.Windows.Forms.CheckBox
    Friend WithEvents chckStuForm137 As System.Windows.Forms.CheckBox
    Friend WithEvents chckStuNSO As System.Windows.Forms.CheckBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtlrn As System.Windows.Forms.TextBox
End Class
