﻿Imports MySql.Data.MySqlClient
Module MLConnection
    Public cn As New MySqlConnection
    Public cm As New MySqlCommand
    Public dr As MySqlDataReader



    Public Sub ConnectionDB()
        With cn
            .ConnectionString = "server=localhost;user id=root;password=;database=rental_system;"
            .Open()
            .Close()
        End With
    End Sub
End Module
