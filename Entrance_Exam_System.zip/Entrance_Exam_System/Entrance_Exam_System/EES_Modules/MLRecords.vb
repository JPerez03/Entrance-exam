﻿Imports System
Imports System.Data
Imports MySql.Data.MySqlClient
Module MLRecords
    Dim conn As MySqlConnection

    Dim dr As MySqlDataReader        'executes cmd
    Dim sql As String
    Public con As MySqlConnection = New MySqlConnection("server=localhost;user id=root; password=; database=eesystem")
    Public cmd As New MySqlCommand
    Public da As New MySqlDataAdapter
    Public dt As New DataTable
    Public Sub transactions_Listahan(ByVal Inventorylist As String)
        Try
            con.Open()
            sql = "SELECT  StudentID,concat(StuName, ' ', StuMiddle, ' ' , 	StuLast), StuAddress, 	StuUser, 	StuPass,  StuAge ,  StuEmail ,  StuCN ,  StuNation ,  StuCivil ,  StuGender , concat(StuNSO,' | ', StuForm137,' | ', 	StuID,' | ',StuTOR),concat(FathFirst , ' ' , FathMiddle, ' ' , FathLast), FathAddress ,  FathAge ,  FathEmail ,  FathCN ,  FathNational ,  FathCS ,  FathGender ,  FathOccu , concat(MothFirst, ' ', MothMiddle, ' ' , MothLast),  MothAddress ,  MothAge ,  MothEmail ,  MothCN ,  MothNational ,  MothCS ,  MothGender ,  MothOccu  FROM stuinfodb;"
            cmd = New MySqlCommand(sql, con)
            dr = cmd.ExecuteReader
            frmExample.ListView1.Items.Clear()
            Dim x As ListViewItem
            Dim y As ListViewItem
            Dim z As ListViewItem
            Do While dr.Read
                x = New ListViewItem(dr(0).ToString())
                x.SubItems.Add(dr(1).ToString())
                x.SubItems.Add(dr(2).ToString())
                x.SubItems.Add(dr(3).ToString())
                x.SubItems.Add("********")
                x.SubItems.Add(dr(5).ToString())
                x.SubItems.Add(dr(6).ToString())
                x.SubItems.Add(dr(7).ToString())
                x.SubItems.Add(dr(8).ToString())
                x.SubItems.Add(dr(9).ToString())
                x.SubItems.Add(dr(10).ToString())
                x.SubItems.Add(dr(11).ToString())

                frmExample.ListView1.Items.Add(x)
                y = New ListViewItem(dr(12).ToString())
                y.SubItems.Add(dr(13).ToString())
                y.SubItems.Add(dr(14).ToString())
                y.SubItems.Add(dr(15).ToString())
                y.SubItems.Add(dr(16).ToString())
                y.SubItems.Add(dr(17).ToString())
                y.SubItems.Add(dr(18).ToString())
                y.SubItems.Add(dr(19).ToString())
                y.SubItems.Add(dr(20).ToString())
                y.SubItems.Add(dr(0).ToString())



                frmExample.ListView2.Items.Add(y)
                z = New ListViewItem(dr(21).ToString())
                z.SubItems.Add(dr(22).ToString())
                z.SubItems.Add(dr(23).ToString())
                z.SubItems.Add(dr(24).ToString())
                z.SubItems.Add(dr(25).ToString())
                z.SubItems.Add(dr(26).ToString())
                z.SubItems.Add(dr(27).ToString())
                z.SubItems.Add(dr(28).ToString())
                z.SubItems.Add(dr(29).ToString())
                x.SubItems.Add(dr(0).ToString())
                frmExample.ListView3.Items.Add(z)
              

            Loop
        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            con.Close()
            cmd.Dispose()
        End Try
    End Sub
    Public Sub BasicInfoStudentData(ByVal Inventorylist As String)
        Try
            con.Open()
            sql = "SELECT  StudentID,StuNation,concat(StuName, ' ', StuMiddle, ' ' , 	StuLast), StuEmail, 	StuCN, 	StuPass,  StuGender , StuAge FROM stuinfodb;"
            cmd = New MySqlCommand(sql, con)
            dr = cmd.ExecuteReader
            frmBISData.ListView1.Items.Clear()
            Dim x As ListViewItem
          
            Do While dr.Read
                x = New ListViewItem(dr(0).ToString())
                x.SubItems.Add(dr(1).ToString())
                x.SubItems.Add(dr(2).ToString())
                x.SubItems.Add(dr(3).ToString())
                x.SubItems.Add(dr(4).ToString())
                x.SubItems.Add(dr(5).ToString())
                x.SubItems.Add(dr(6).ToString())
                x.SubItems.Add(dr(7).ToString())
                

                frmBISData.ListView1.Items.Add(x)
                 
            Loop
        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            con.Close()
            cmd.Dispose()
        End Try
    End Sub

End Module
