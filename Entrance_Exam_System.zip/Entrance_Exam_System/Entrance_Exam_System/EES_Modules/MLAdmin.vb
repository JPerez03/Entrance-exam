﻿Imports System
Imports System.Data
Imports MySql.Data.MySqlClient
Module MLAdmin
    Dim dr As MySqlDataReader        'executes cmd
    Dim sql As String
    Dim ss As String
    Dim var_con As String = "Server=127.0.0.1;Port=3306;Database=eesystem;Uid=root; Pwd=;"
    Public con As MySqlConnection = New MySqlConnection("server=localhost;user id=root; password=; database=eesystem")
    Public cmd As New MySqlCommand
    Public da As New MySqlDataAdapter
    Public dt As New DataTable

    Public Sub AdminLog(ByVal LoginUser As String)

        Try
            con = New MySqlConnection(var_con)
            con.Open()
            sql = "select * from admininfodb where Admin_User = '" & frmAdminLog.txtAdminUser.Text & "' And Admin_Pass = '" & frmAdminLog.txtAdminPass.Text & "';"
            con = New MySqlConnection(var_con)
            con.Open()
            cmd = New MySqlCommand(sql, con)
            dr = cmd.ExecuteReader
            If dr.Read() Then
                MsgBox("Welcome Admin", MsgBoxStyle.Information)
                frmMainformofADMIN.Show()
                frmAdminLog.Hide()
            Else
                MsgBox("Please Try Again", MsgBoxStyle.Exclamation)
                frmAdminLog.txtAdminUser.Clear()
                frmAdminLog.txtAdminPass.Clear()

            End If
            dr.Close()
            con.Close()

        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub
End Module
