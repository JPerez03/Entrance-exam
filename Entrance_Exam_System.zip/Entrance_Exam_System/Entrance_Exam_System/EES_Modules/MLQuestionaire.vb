﻿Imports System
Imports System.Data
Imports MySql.Data.MySqlClient
Module MLQuestionaire
    Dim dr As MySqlDataReader        'executes cmd
    Dim sql As String
    Dim ss As String
    Dim var_con As String = "Server=127.0.0.1;Port=3306;Database=eesystem;Uid=root; Pwd=;"
    Public con As MySqlConnection = New MySqlConnection("server=localhost;user id=root; password=; database=eesystem")
    Public cmd As New MySqlCommand
    Public da As New MySqlDataAdapter
    Public dt As New DataTable
    Public Sub ADDQUESTION(ByVal SignUpdate As String)
        
        con.Open()
        Try
            sql = "INSERT INTO questionnaire(Question ,Choice1 ,Choice2 ,Choice3 ,	Choice4 ,Crct_Ans ,	Pnts) VALUES( '" & frmMaintenance.txtQUEST.Text & "', '" & frmMaintenance.txtChc1.Text & "', '" & frmMaintenance.txtChc2.Text & "', '" & frmMaintenance.txtChc3.Text & "', '" & frmMaintenance.txtChc4.Text & "', '" & frmMaintenance.txtAns.Text & "','" & frmMaintenance.txtPts.Text & "')"

            cmd.CommandText = sql
            cmd.Connection = con
            cmd.ExecuteNonQuery()
            MsgBox("Record has been saved!", MsgBoxStyle.Information, "System Message")
            con.Close()
        Catch ex As Exception
            MsgBox("Unable to save record!", MsgBoxStyle.Critical, "System Message")
            con.Close()
        End Try
    End Sub
    Public Sub Questionnaire(ByVal LoginUser As String)

        
    End Sub
End Module
