﻿Imports System
Imports System.Data
Imports MySql.Data.MySqlClient
Module MlStudents
    Dim dr As MySqlDataReader        'executes cmd
    Dim sql As String
    Dim ss As String
    Dim var_con As String = "Server=127.0.0.1;Port=3306;Database=eesystem;Uid=root; Pwd=;"
    Public con As MySqlConnection = New MySqlConnection("server=localhost;user id=root; password=; database=eesystem")
    Public cmd As New MySqlCommand
    Public da As New MySqlDataAdapter
    Public dt As New DataTable
    Public Sub SignUp(ByVal SignUpdate As String)
        If FillForm.txtFN.Text = "" Then
            MsgBox("Please complete the fields!", MsgBoxStyle.Exclamation, "System Message")
        End If
        con.Open()
        Try
            sql = "INSERT INTO stuinfodb(StuName ,StuMiddle ,StuLast ,StuAddress ,StuUser ,StuPass ,StuAge ,StuEmail ,StuCN ,StuNation ,StuCivil ,StuGender ,StuNSO ,StuForm137 ,StuID ,StuTOR ,FathFirst ,FathMiddle ,FathLast ,FathAddress ,FathAge ,FathEmail ,FathCN ,FathNational ,FathCS ,FathGender ,FathOccu ,MothFirst ,MothMiddle ,MothLast ,MothAddress ,MothAge ,MothEmail ,MothCN ,MothNational ,MothCS ,MothGender ,MothOccu) VALUES( '" & FillForm.txtFN.Text & "', '" & FillForm.txtMN.Text & "', '" & FillForm.txtLN.Text & "', '" & FillForm.txtAdd.Text & "', '" & FillForm.txtUser.Text & "', '" & FillForm.txtPass.Text & "','" & FillForm.txtStuAge.Text & "','" & FillForm.txtStuEmail.Text & "','" & FillForm.txtStuCN.Text & "' ,'" & FillForm.cmbStuNational.Text & "','" & FillForm.cmbStuCS.Text & "', '" & FillForm.cmbStuGender.Text & "','" & FillForm.chckStuNSO.Text & "','" & FillForm.chckStuForm137.Text & "','" & FillForm.chckStuID.Text & "','" & FillForm.chckStuTOR.Text & "','" & FillForm.txtFatFN.Text & "','" & FillForm.txtFatMN.Text & "','" & FillForm.txtFatLN.Text & "','" & FillForm.txtFatAdd.Text & "','" & FillForm.txtFatAge.Text & "','" & FillForm.txtFatEmail.Text & "','" & FillForm.txtFatCN.Text & "','" & FillForm.cmbFatNational.Text & "','" & FillForm.cmbFatCS.Text & "','" & FillForm.cmbFatGender.Text & "','" & FillForm.txtFatOccu.Text & "','" & FillForm.txtMothFN.Text & "','" & FillForm.txtMothMN.Text & "','" & FillForm.txtMothLN.Text & "','" & FillForm.txtMothAdd.Text & "','" & FillForm.txtMothAge.Text & "','" & FillForm.txtMothEmail.Text & "','" & FillForm.txtMothCN.Text & "','" & FillForm.cmbMothNational.Text & "','" & FillForm.cmbMothCS.Text & "','" & FillForm.cmbMothGender.Text & "','" & FillForm.txtMothOccu.Text & "')"

            cmd.CommandText = sql
            cmd.Connection = con
            cmd.ExecuteNonQuery()
            MsgBox("Record has been saved!", MsgBoxStyle.Information, "System Message")
            con.Close()
        Catch ex As Exception
            MsgBox("Unable to save record!", MsgBoxStyle.Critical, "System Message")
            con.Close()
        End Try
    End Sub
    Public Sub StuName(ByVal StudentName As String)

    End Sub
    Public Sub LoginUps(ByVal LoginUser As String)

        Try
            con = New MySqlConnection(var_con)
            con.Open()
            sql = "select * from stuinfodb where StuUser = '" & frmStuLogin.txtStuUser.Text & "' And StuPass = '" & frmStuLogin.txtStuPass.Text & "';"
            con = New MySqlConnection(var_con)
            con.Open()
            cmd = New MySqlCommand(sql, con)
            dr = cmd.ExecuteReader
            If dr.Read() Then
                MsgBox("Welcome Student", MsgBoxStyle.Information)
                frmExamStu.Show()
                frmStuLogin.Hide()
            Else
                MsgBox("Please Try Again", MsgBoxStyle.Exclamation)
                frmStuLogin.txtStuUser.Clear()
                frmStuLogin.txtStuPass.Clear()

            End If
            dr.Close()
            con.Close()

        Catch ex As Exception
            MsgBox("error")
        End Try
    End Sub
End Module
