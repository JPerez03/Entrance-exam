﻿Imports System
Imports System.Data
Imports MySql.Data.MySqlClient
Public Class frmExamination
    Dim dr As MySqlDataReader        'executes cmd
    Dim sql As String
    Dim ss As String
    Dim var_con As String = "Server=127.0.0.1;Port=3306;Database=eesystem;Uid=root; Pwd=;"
    Public con As MySqlConnection = New MySqlConnection("server=localhost;user id=root; password=; database=eesystem")
    Public cmd As New MySqlCommand
    Public da As New MySqlDataAdapter
    Public dt As New DataTable
    Dim qid As Integer = 4 'variable with fixed value of 1

    Private Sub frmExamination_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Call loadQuestions()


        lblquestion.Text = "Click 'START' to Start Exam now!"
        Panel2.Hide()
        Panel3.Hide()

    End Sub

    Private Sub StartToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StartToolStripMenuItem.Click

        If MsgBox("Are you sure you want to Start Exam?", vbQuestion + vbYesNo, "Start Exam") = MsgBoxResult.No Then Exit Sub

        Call loadQuestions() 'load question
        Panel2.Show()
        Panel3.Show()


    End Sub


    Public Sub malupet()
        If qid = 9 Then
            Dim fqid As Integer = qid + 1
        End If
    End Sub
    Public Sub scoremo()
        If lblpnts.Text = "10" Then
            lblscore.Text = +10
        End If
    End Sub
    Public Sub corecans()
        If lblANS.Text = lblCans.Text Then
            lblpnts.Text = "10"
            lblscore.Text = +10

           
        Else
            lblpnts.Text = "0"
            
        End If
    End Sub
    Public Sub showdone()
        Dim fqid As Integer = qid + 1
        If fqid = 10 Then
            DoneToolStripMenuItem.Enabled = True
            StartToolStripMenuItem.Enabled = False
            lblquestion.Text = "CLICK DONE TO NEXT SUBJECT"
            Panel2.Hide()
            Panel3.Hide()
        End If
    End Sub
    Public Sub enablingbuttonsya()
        If btnCHC1.CanSelect Then
            btnNXT.Enabled = True
        End If
    End Sub

    Public Sub loadQuestions()
        con.Open()
        sql = "SELECT * FROM questionnaire WHERE QSNT_ID=" & qid & ""
        cmd = New MySqlCommand(sql, con)
        dr = cmd.ExecuteReader

        'Looping
        While dr.Read
            'Send Value to Control
            lblquestion.Text = dr("Question")
            btnCHC1.Text = dr("Choice1")
            btnCHC2.Text = dr("Choice2")
            btnCHC3.Text = dr("Choice3")
            btnCHC4.Text = dr("Choice4")
            lblCans.Text = dr("Crct_Ans")

        End While
        dr.Close()
        con.Close()
    End Sub
     
    Private Sub btnCHC1_Click(sender As Object, e As EventArgs) Handles btnCHC1.Click
        lblANS.Text = btnCHC1.Text
        Call corecans()
    End Sub
    Private Sub btnCHC2_Click(sender As Object, e As EventArgs) Handles btnCHC2.Click
        lblANS.Text = btnCHC2.Text
        Call corecans()
    End Sub

    Private Sub btnCHC3_Click(sender As Object, e As EventArgs) Handles btnCHC3.Click
        lblANS.Text = btnCHC3.Text
        Call corecans()
    End Sub
    Private Sub btnCHC4_Click(sender As Object, e As EventArgs) Handles btnCHC4.Click
        lblANS.Text = btnCHC4.Text
        Call corecans()
    End Sub

    Private Sub btnNXT_Click(sender As Object, e As EventArgs) Handles btnNXT.Click
       
        qid += 1
        Call loadQuestions()

        Call malupet()
        Call showdone()
        'Call insertRESULT()
        lblANS.Text = ""
         



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        qid -= 1
        Call loadQuestions()
        lblANS.Text = ""
    End Sub

    Private Sub lblpnts_Click(sender As Object, e As EventArgs) Handles lblpnts.Click

    End Sub

    Private Sub DoneToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DoneToolStripMenuItem.Click
        qid = 4
        frmRESULTEXAM.Show()
        If lblpnts.Text = "10" Then
            frmRESULTEXAM.Label1.Text = "10"


        End If
    End Sub
End Class