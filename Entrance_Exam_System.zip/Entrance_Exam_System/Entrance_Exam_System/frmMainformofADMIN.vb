﻿Public Class frmMainformofADMIN

 

    Private Sub ListOfStudentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListOfStudentsToolStripMenuItem.Click
        frmBISData.Show()
    End Sub
End Class