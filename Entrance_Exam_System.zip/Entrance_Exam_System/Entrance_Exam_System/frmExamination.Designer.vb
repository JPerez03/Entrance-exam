﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmExamination
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblquestion = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.StartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DoneToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnCHC1 = New System.Windows.Forms.Button()
        Me.btnCHC2 = New System.Windows.Forms.Button()
        Me.btnCHC3 = New System.Windows.Forms.Button()
        Me.btnCHC4 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblCans = New System.Windows.Forms.Label()
        Me.lblpnts = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnNXT = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblANS = New System.Windows.Forms.Label()
        Me.lblscore = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.Panel1.Controls.Add(Me.lblscore)
        Me.Panel1.Controls.Add(Me.lblquestion)
        Me.Panel1.Controls.Add(Me.MenuStrip1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1007, 196)
        Me.Panel1.TabIndex = 0
        '
        'lblquestion
        '
        Me.lblquestion.BackColor = System.Drawing.Color.White
        Me.lblquestion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblquestion.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblquestion.Location = New System.Drawing.Point(0, 24)
        Me.lblquestion.Name = "lblquestion"
        Me.lblquestion.Size = New System.Drawing.Size(1007, 172)
        Me.lblquestion.TabIndex = 0
        Me.lblquestion.Text = "Label1"
        Me.lblquestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartToolStripMenuItem, Me.DoneToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1007, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'StartToolStripMenuItem
        '
        Me.StartToolStripMenuItem.Name = "StartToolStripMenuItem"
        Me.StartToolStripMenuItem.Size = New System.Drawing.Size(43, 20)
        Me.StartToolStripMenuItem.Text = "Start"
        '
        'DoneToolStripMenuItem
        '
        Me.DoneToolStripMenuItem.Enabled = False
        Me.DoneToolStripMenuItem.Name = "DoneToolStripMenuItem"
        Me.DoneToolStripMenuItem.Size = New System.Drawing.Size(47, 20)
        Me.DoneToolStripMenuItem.Text = "Done"
        '
        'btnCHC1
        '
        Me.btnCHC1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCHC1.Location = New System.Drawing.Point(50, 28)
        Me.btnCHC1.Name = "btnCHC1"
        Me.btnCHC1.Size = New System.Drawing.Size(896, 57)
        Me.btnCHC1.TabIndex = 1
        Me.btnCHC1.Text = "A"
        Me.btnCHC1.UseVisualStyleBackColor = True
        '
        'btnCHC2
        '
        Me.btnCHC2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCHC2.Location = New System.Drawing.Point(50, 115)
        Me.btnCHC2.Name = "btnCHC2"
        Me.btnCHC2.Size = New System.Drawing.Size(896, 57)
        Me.btnCHC2.TabIndex = 2
        Me.btnCHC2.Text = "B"
        Me.btnCHC2.UseVisualStyleBackColor = True
        '
        'btnCHC3
        '
        Me.btnCHC3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCHC3.Location = New System.Drawing.Point(50, 204)
        Me.btnCHC3.Name = "btnCHC3"
        Me.btnCHC3.Size = New System.Drawing.Size(896, 57)
        Me.btnCHC3.TabIndex = 3
        Me.btnCHC3.Text = "C"
        Me.btnCHC3.UseVisualStyleBackColor = True
        '
        'btnCHC4
        '
        Me.btnCHC4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCHC4.Location = New System.Drawing.Point(50, 286)
        Me.btnCHC4.Name = "btnCHC4"
        Me.btnCHC4.Size = New System.Drawing.Size(896, 57)
        Me.btnCHC4.TabIndex = 4
        Me.btnCHC4.Text = "D"
        Me.btnCHC4.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.Panel2.Controls.Add(Me.btnCHC1)
        Me.Panel2.Controls.Add(Me.btnCHC2)
        Me.Panel2.Controls.Add(Me.btnCHC3)
        Me.Panel2.Controls.Add(Me.btnCHC4)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 196)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1007, 514)
        Me.Panel2.TabIndex = 9
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Panel3.Controls.Add(Me.lblCans)
        Me.Panel3.Controls.Add(Me.lblpnts)
        Me.Panel3.Controls.Add(Me.Button1)
        Me.Panel3.Controls.Add(Me.btnNXT)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.lblANS)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(0, 604)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1007, 106)
        Me.Panel3.TabIndex = 10
        '
        'lblCans
        '
        Me.lblCans.AutoSize = True
        Me.lblCans.Location = New System.Drawing.Point(319, 39)
        Me.lblCans.Name = "lblCans"
        Me.lblCans.Size = New System.Drawing.Size(39, 13)
        Me.lblCans.TabIndex = 5
        Me.lblCans.Text = "Label4"
        Me.lblCans.Visible = False
        '
        'lblpnts
        '
        Me.lblpnts.AutoSize = True
        Me.lblpnts.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpnts.Location = New System.Drawing.Point(184, 69)
        Me.lblpnts.Name = "lblpnts"
        Me.lblpnts.Size = New System.Drawing.Size(61, 25)
        Me.lblpnts.TabIndex = 4
        Me.lblpnts.Text = "Points"
        Me.lblpnts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblpnts.Visible = False
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(650, 21)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(146, 43)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "PREVIOUS"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnNXT
        '
        Me.btnNXT.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNXT.Location = New System.Drawing.Point(839, 21)
        Me.btnNXT.Name = "btnNXT"
        Me.btnNXT.Size = New System.Drawing.Size(146, 43)
        Me.btnNXT.TabIndex = 0
        Me.btnNXT.Text = "NEXT"
        Me.btnNXT.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(25, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(124, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Your Answer :"
        '
        'lblANS
        '
        Me.lblANS.AutoSize = True
        Me.lblANS.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblANS.Location = New System.Drawing.Point(155, 39)
        Me.lblANS.Name = "lblANS"
        Me.lblANS.Size = New System.Drawing.Size(66, 25)
        Me.lblANS.TabIndex = 0
        Me.lblANS.Text = "Label1"
        '
        'lblscore
        '
        Me.lblscore.AutoSize = True
        Me.lblscore.Location = New System.Drawing.Point(864, 9)
        Me.lblscore.Name = "lblscore"
        Me.lblscore.Size = New System.Drawing.Size(39, 13)
        Me.lblscore.TabIndex = 2
        Me.lblscore.Text = "Label1"
        '
        'frmExamination
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1007, 710)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "frmExamination"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmExamination"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblquestion As System.Windows.Forms.Label
    Friend WithEvents btnCHC1 As System.Windows.Forms.Button
    Friend WithEvents btnCHC2 As System.Windows.Forms.Button
    Friend WithEvents btnCHC3 As System.Windows.Forms.Button
    Friend WithEvents btnCHC4 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblANS As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents StartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnNXT As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents lblCans As System.Windows.Forms.Label
    Friend WithEvents lblpnts As System.Windows.Forms.Label
    Friend WithEvents DoneToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblscore As System.Windows.Forms.Label
End Class
