﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMainformofADMIN
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ListOfStudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ListOfSubjectsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MathToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnglishToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FilipinoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogicToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScienceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.MenuStrip1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1362, 54)
        Me.Panel1.TabIndex = 1
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ListOfStudentsToolStripMenuItem, Me.ListOfSubjectsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1362, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ListOfStudentsToolStripMenuItem
        '
        Me.ListOfStudentsToolStripMenuItem.Name = "ListOfStudentsToolStripMenuItem"
        Me.ListOfStudentsToolStripMenuItem.Size = New System.Drawing.Size(100, 20)
        Me.ListOfStudentsToolStripMenuItem.Text = "List of Students"
        '
        'Panel2
        '
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 697)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1362, 44)
        Me.Panel2.TabIndex = 2
        '
        'ListOfSubjectsToolStripMenuItem
        '
        Me.ListOfSubjectsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MathToolStripMenuItem, Me.EnglishToolStripMenuItem, Me.FilipinoToolStripMenuItem, Me.LogicToolStripMenuItem, Me.ScienceToolStripMenuItem})
        Me.ListOfSubjectsToolStripMenuItem.Name = "ListOfSubjectsToolStripMenuItem"
        Me.ListOfSubjectsToolStripMenuItem.Size = New System.Drawing.Size(98, 20)
        Me.ListOfSubjectsToolStripMenuItem.Text = "List of Subjects"
        '
        'MathToolStripMenuItem
        '
        Me.MathToolStripMenuItem.Name = "MathToolStripMenuItem"
        Me.MathToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.MathToolStripMenuItem.Text = "Math"
        '
        'EnglishToolStripMenuItem
        '
        Me.EnglishToolStripMenuItem.Name = "EnglishToolStripMenuItem"
        Me.EnglishToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.EnglishToolStripMenuItem.Text = "English"
        '
        'FilipinoToolStripMenuItem
        '
        Me.FilipinoToolStripMenuItem.Name = "FilipinoToolStripMenuItem"
        Me.FilipinoToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.FilipinoToolStripMenuItem.Text = "Filipino"
        '
        'LogicToolStripMenuItem
        '
        Me.LogicToolStripMenuItem.Name = "LogicToolStripMenuItem"
        Me.LogicToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.LogicToolStripMenuItem.Text = "Logic"
        '
        'ScienceToolStripMenuItem
        '
        Me.ScienceToolStripMenuItem.Name = "ScienceToolStripMenuItem"
        Me.ScienceToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ScienceToolStripMenuItem.Text = "Science"
        '
        'frmMainformofADMIN
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 741)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmMainformofADMIN"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ListOfStudentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ListOfSubjectsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MathToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnglishToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FilipinoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogicToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScienceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
