﻿Public Class frmStuDecision

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        FillForm.Show()
        FillForm.txtlrn.Text = FillForm.txtlrn.Text + 1

        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        frmStuLogin.Show()
        Me.Hide()
    End Sub
End Class