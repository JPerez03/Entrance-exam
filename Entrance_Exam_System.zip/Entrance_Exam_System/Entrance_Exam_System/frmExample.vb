﻿Public Class frmExample
    Public transaction As String = ""
    Private Sub loadlols()

    End Sub
    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged, ListView2.SelectedIndexChanged, ListView3.SelectedIndexChanged
       

    End Sub

    Private Sub frmExample_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        transactions_Listahan(transaction)
       

    End Sub
End Class