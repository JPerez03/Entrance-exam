﻿Public Class frmExamStu
 

    

    Private Sub BunifuGradientPanel1_Paint(sender As Object, e As PaintEventArgs) Handles BunifuGradientPanel1.Paint
        If prcnt1.Value = 100 Then
            Button1.Enabled = False
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        frmENGLISHQUESTION.Show()
        Me.Hide()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles btnDONE.Click
       
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint
        If prcnt1.Value = 100 And prcnt2.Value = 100 And prcnt3.Value = 100 And prcnt4.Value = 100 And prcnt5.Value = 100 Then
            btnDONE.Enabled = True
        End If
    End Sub
End Class