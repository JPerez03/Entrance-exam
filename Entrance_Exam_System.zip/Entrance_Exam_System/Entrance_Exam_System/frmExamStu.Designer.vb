﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmExamStu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmExamStu))
        Me.prcnt1 = New Bunifu.Framework.UI.BunifuGauge()
        Me.BunifuGradientPanel1 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblENGEXAM = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BunifuGradientPanel2 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblFILIPINO = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.prcnt2 = New Bunifu.Framework.UI.BunifuGauge()
        Me.BunifuGradientPanel3 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblLOGIC = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.prcnt3 = New Bunifu.Framework.UI.BunifuGauge()
        Me.BunifuGradientPanel4 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblMATH = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.prcnt4 = New Bunifu.Framework.UI.BunifuGauge()
        Me.BunifuGradientPanel5 = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblSCIENCE = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.prcnt5 = New Bunifu.Framework.UI.BunifuGauge()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnDONE = New System.Windows.Forms.Button()
        Me.BunifuGradientPanel1.SuspendLayout()
        Me.BunifuGradientPanel2.SuspendLayout()
        Me.BunifuGradientPanel3.SuspendLayout()
        Me.BunifuGradientPanel4.SuspendLayout()
        Me.BunifuGradientPanel5.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'prcnt1
        '
        Me.prcnt1.BackgroundImage = CType(resources.GetObject("prcnt1.BackgroundImage"), System.Drawing.Image)
        Me.prcnt1.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.prcnt1.Location = New System.Drawing.Point(194, 16)
        Me.prcnt1.Margin = New System.Windows.Forms.Padding(6)
        Me.prcnt1.Name = "prcnt1"
        Me.prcnt1.ProgressBgColor = System.Drawing.Color.Gray
        Me.prcnt1.ProgressColor1 = System.Drawing.Color.SeaGreen
        Me.prcnt1.ProgressColor2 = System.Drawing.Color.Tomato
        Me.prcnt1.Size = New System.Drawing.Size(188, 129)
        Me.prcnt1.TabIndex = 0
        Me.prcnt1.Thickness = 30
        Me.prcnt1.Value = 0
        '
        'BunifuGradientPanel1
        '
        Me.BunifuGradientPanel1.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel1.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel1.Controls.Add(Me.Label2)
        Me.BunifuGradientPanel1.Controls.Add(Me.lblENGEXAM)
        Me.BunifuGradientPanel1.Controls.Add(Me.Button1)
        Me.BunifuGradientPanel1.Controls.Add(Me.prcnt1)
        Me.BunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel1.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel1.Location = New System.Drawing.Point(25, 30)
        Me.BunifuGradientPanel1.Name = "BunifuGradientPanel1"
        Me.BunifuGradientPanel1.Quality = 10
        Me.BunifuGradientPanel1.Size = New System.Drawing.Size(403, 163)
        Me.BunifuGradientPanel1.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(91, 132)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "/ 100"
        '
        'lblENGEXAM
        '
        Me.lblENGEXAM.AutoSize = True
        Me.lblENGEXAM.BackColor = System.Drawing.Color.Transparent
        Me.lblENGEXAM.Location = New System.Drawing.Point(69, 132)
        Me.lblENGEXAM.Name = "lblENGEXAM"
        Me.lblENGEXAM.Size = New System.Drawing.Size(13, 13)
        Me.lblENGEXAM.TabIndex = 2
        Me.lblENGEXAM.Text = "0"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Stencil", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(25, 42)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(144, 71)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "English" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Subject"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'BunifuGradientPanel2
        '
        Me.BunifuGradientPanel2.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel2.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel2.Controls.Add(Me.Label1)
        Me.BunifuGradientPanel2.Controls.Add(Me.lblFILIPINO)
        Me.BunifuGradientPanel2.Controls.Add(Me.Button2)
        Me.BunifuGradientPanel2.Controls.Add(Me.prcnt2)
        Me.BunifuGradientPanel2.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel2.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel2.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel2.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel2.Location = New System.Drawing.Point(493, 30)
        Me.BunifuGradientPanel2.Name = "BunifuGradientPanel2"
        Me.BunifuGradientPanel2.Quality = 10
        Me.BunifuGradientPanel2.Size = New System.Drawing.Size(403, 163)
        Me.BunifuGradientPanel2.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(91, 132)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "/ 100"
        '
        'lblFILIPINO
        '
        Me.lblFILIPINO.AutoSize = True
        Me.lblFILIPINO.BackColor = System.Drawing.Color.Transparent
        Me.lblFILIPINO.Location = New System.Drawing.Point(69, 132)
        Me.lblFILIPINO.Name = "lblFILIPINO"
        Me.lblFILIPINO.Size = New System.Drawing.Size(13, 13)
        Me.lblFILIPINO.TabIndex = 2
        Me.lblFILIPINO.Text = "0"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.Font = New System.Drawing.Font("Stencil", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(25, 42)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(144, 71)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Filipino" & Global.Microsoft.VisualBasic.ChrW(10) & " Subject"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'prcnt2
        '
        Me.prcnt2.BackgroundImage = CType(resources.GetObject("prcnt2.BackgroundImage"), System.Drawing.Image)
        Me.prcnt2.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.prcnt2.Location = New System.Drawing.Point(194, 16)
        Me.prcnt2.Margin = New System.Windows.Forms.Padding(6)
        Me.prcnt2.Name = "prcnt2"
        Me.prcnt2.ProgressBgColor = System.Drawing.Color.Gray
        Me.prcnt2.ProgressColor1 = System.Drawing.Color.SeaGreen
        Me.prcnt2.ProgressColor2 = System.Drawing.Color.Tomato
        Me.prcnt2.Size = New System.Drawing.Size(188, 129)
        Me.prcnt2.TabIndex = 0
        Me.prcnt2.Thickness = 30
        Me.prcnt2.Value = 0
        '
        'BunifuGradientPanel3
        '
        Me.BunifuGradientPanel3.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel3.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel3.Controls.Add(Me.Label4)
        Me.BunifuGradientPanel3.Controls.Add(Me.lblLOGIC)
        Me.BunifuGradientPanel3.Controls.Add(Me.Button3)
        Me.BunifuGradientPanel3.Controls.Add(Me.prcnt3)
        Me.BunifuGradientPanel3.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel3.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel3.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel3.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel3.Location = New System.Drawing.Point(25, 250)
        Me.BunifuGradientPanel3.Name = "BunifuGradientPanel3"
        Me.BunifuGradientPanel3.Quality = 10
        Me.BunifuGradientPanel3.Size = New System.Drawing.Size(403, 163)
        Me.BunifuGradientPanel3.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(91, 132)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "/ 100"
        '
        'lblLOGIC
        '
        Me.lblLOGIC.AutoSize = True
        Me.lblLOGIC.BackColor = System.Drawing.Color.Transparent
        Me.lblLOGIC.Location = New System.Drawing.Point(69, 132)
        Me.lblLOGIC.Name = "lblLOGIC"
        Me.lblLOGIC.Size = New System.Drawing.Size(13, 13)
        Me.lblLOGIC.TabIndex = 2
        Me.lblLOGIC.Text = "0"
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.Font = New System.Drawing.Font("Stencil", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(25, 42)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(144, 71)
        Me.Button3.TabIndex = 1
        Me.Button3.Text = "Logic" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Subject"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'prcnt3
        '
        Me.prcnt3.BackgroundImage = CType(resources.GetObject("prcnt3.BackgroundImage"), System.Drawing.Image)
        Me.prcnt3.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.prcnt3.Location = New System.Drawing.Point(194, 16)
        Me.prcnt3.Margin = New System.Windows.Forms.Padding(6)
        Me.prcnt3.Name = "prcnt3"
        Me.prcnt3.ProgressBgColor = System.Drawing.Color.Gray
        Me.prcnt3.ProgressColor1 = System.Drawing.Color.SeaGreen
        Me.prcnt3.ProgressColor2 = System.Drawing.Color.Tomato
        Me.prcnt3.Size = New System.Drawing.Size(188, 129)
        Me.prcnt3.TabIndex = 0
        Me.prcnt3.Thickness = 30
        Me.prcnt3.Value = 0
        '
        'BunifuGradientPanel4
        '
        Me.BunifuGradientPanel4.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel4.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel4.Controls.Add(Me.Label6)
        Me.BunifuGradientPanel4.Controls.Add(Me.lblMATH)
        Me.BunifuGradientPanel4.Controls.Add(Me.Button4)
        Me.BunifuGradientPanel4.Controls.Add(Me.prcnt4)
        Me.BunifuGradientPanel4.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel4.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel4.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel4.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel4.Location = New System.Drawing.Point(493, 250)
        Me.BunifuGradientPanel4.Name = "BunifuGradientPanel4"
        Me.BunifuGradientPanel4.Quality = 10
        Me.BunifuGradientPanel4.Size = New System.Drawing.Size(403, 163)
        Me.BunifuGradientPanel4.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Location = New System.Drawing.Point(91, 132)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(33, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "/ 100"
        '
        'lblMATH
        '
        Me.lblMATH.AutoSize = True
        Me.lblMATH.BackColor = System.Drawing.Color.Transparent
        Me.lblMATH.Location = New System.Drawing.Point(69, 132)
        Me.lblMATH.Name = "lblMATH"
        Me.lblMATH.Size = New System.Drawing.Size(13, 13)
        Me.lblMATH.TabIndex = 2
        Me.lblMATH.Text = "0"
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.Font = New System.Drawing.Font("Stencil", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(25, 42)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(144, 71)
        Me.Button4.TabIndex = 1
        Me.Button4.Text = "Math" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Subject"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'prcnt4
        '
        Me.prcnt4.BackgroundImage = CType(resources.GetObject("prcnt4.BackgroundImage"), System.Drawing.Image)
        Me.prcnt4.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.prcnt4.Location = New System.Drawing.Point(194, 16)
        Me.prcnt4.Margin = New System.Windows.Forms.Padding(6)
        Me.prcnt4.Name = "prcnt4"
        Me.prcnt4.ProgressBgColor = System.Drawing.Color.Gray
        Me.prcnt4.ProgressColor1 = System.Drawing.Color.SeaGreen
        Me.prcnt4.ProgressColor2 = System.Drawing.Color.Tomato
        Me.prcnt4.Size = New System.Drawing.Size(188, 129)
        Me.prcnt4.TabIndex = 0
        Me.prcnt4.Thickness = 30
        Me.prcnt4.Value = 0
        '
        'BunifuGradientPanel5
        '
        Me.BunifuGradientPanel5.BackgroundImage = CType(resources.GetObject("BunifuGradientPanel5.BackgroundImage"), System.Drawing.Image)
        Me.BunifuGradientPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuGradientPanel5.Controls.Add(Me.Label8)
        Me.BunifuGradientPanel5.Controls.Add(Me.lblSCIENCE)
        Me.BunifuGradientPanel5.Controls.Add(Me.Button5)
        Me.BunifuGradientPanel5.Controls.Add(Me.prcnt5)
        Me.BunifuGradientPanel5.GradientBottomLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel5.GradientBottomRight = System.Drawing.Color.White
        Me.BunifuGradientPanel5.GradientTopLeft = System.Drawing.Color.White
        Me.BunifuGradientPanel5.GradientTopRight = System.Drawing.Color.White
        Me.BunifuGradientPanel5.Location = New System.Drawing.Point(259, 465)
        Me.BunifuGradientPanel5.Name = "BunifuGradientPanel5"
        Me.BunifuGradientPanel5.Quality = 10
        Me.BunifuGradientPanel5.Size = New System.Drawing.Size(403, 163)
        Me.BunifuGradientPanel5.TabIndex = 6
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Location = New System.Drawing.Point(91, 132)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(33, 13)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "/ 100"
        '
        'lblSCIENCE
        '
        Me.lblSCIENCE.AutoSize = True
        Me.lblSCIENCE.BackColor = System.Drawing.Color.Transparent
        Me.lblSCIENCE.Location = New System.Drawing.Point(69, 132)
        Me.lblSCIENCE.Name = "lblSCIENCE"
        Me.lblSCIENCE.Size = New System.Drawing.Size(13, 13)
        Me.lblSCIENCE.TabIndex = 2
        Me.lblSCIENCE.Text = "0"
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button5.Font = New System.Drawing.Font("Stencil", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(25, 42)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(144, 71)
        Me.Button5.TabIndex = 1
        Me.Button5.Text = "Science" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Subject"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'prcnt5
        '
        Me.prcnt5.BackgroundImage = CType(resources.GetObject("prcnt5.BackgroundImage"), System.Drawing.Image)
        Me.prcnt5.Font = New System.Drawing.Font("Century Gothic", 15.75!)
        Me.prcnt5.Location = New System.Drawing.Point(194, 16)
        Me.prcnt5.Margin = New System.Windows.Forms.Padding(6)
        Me.prcnt5.Name = "prcnt5"
        Me.prcnt5.ProgressBgColor = System.Drawing.Color.Gray
        Me.prcnt5.ProgressColor1 = System.Drawing.Color.SeaGreen
        Me.prcnt5.ProgressColor2 = System.Drawing.Color.Tomato
        Me.prcnt5.Size = New System.Drawing.Size(188, 129)
        Me.prcnt5.TabIndex = 0
        Me.prcnt5.Thickness = 30
        Me.prcnt5.Value = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnDONE)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 648)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(906, 60)
        Me.Panel1.TabIndex = 7
        '
        'btnDONE
        '
        Me.btnDONE.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnDONE.Enabled = False
        Me.btnDONE.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnDONE.Font = New System.Drawing.Font("Stencil", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDONE.Location = New System.Drawing.Point(762, 19)
        Me.btnDONE.Name = "btnDONE"
        Me.btnDONE.Size = New System.Drawing.Size(83, 29)
        Me.btnDONE.TabIndex = 0
        Me.btnDONE.Text = "DONE"
        Me.btnDONE.UseVisualStyleBackColor = False
        '
        'frmExamStu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(906, 708)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.BunifuGradientPanel5)
        Me.Controls.Add(Me.BunifuGradientPanel4)
        Me.Controls.Add(Me.BunifuGradientPanel3)
        Me.Controls.Add(Me.BunifuGradientPanel2)
        Me.Controls.Add(Me.BunifuGradientPanel1)
        Me.Name = "frmExamStu"
        Me.Text = "frmExamStu"
        Me.BunifuGradientPanel1.ResumeLayout(False)
        Me.BunifuGradientPanel1.PerformLayout()
        Me.BunifuGradientPanel2.ResumeLayout(False)
        Me.BunifuGradientPanel2.PerformLayout()
        Me.BunifuGradientPanel3.ResumeLayout(False)
        Me.BunifuGradientPanel3.PerformLayout()
        Me.BunifuGradientPanel4.ResumeLayout(False)
        Me.BunifuGradientPanel4.PerformLayout()
        Me.BunifuGradientPanel5.ResumeLayout(False)
        Me.BunifuGradientPanel5.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents prcnt1 As Bunifu.Framework.UI.BunifuGauge
    Friend WithEvents BunifuGradientPanel1 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblENGEXAM As System.Windows.Forms.Label
    Friend WithEvents BunifuGradientPanel2 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblFILIPINO As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents prcnt2 As Bunifu.Framework.UI.BunifuGauge
    Friend WithEvents BunifuGradientPanel3 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblLOGIC As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents prcnt3 As Bunifu.Framework.UI.BunifuGauge
    Friend WithEvents BunifuGradientPanel4 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblMATH As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents prcnt4 As Bunifu.Framework.UI.BunifuGauge
    Friend WithEvents BunifuGradientPanel5 As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblSCIENCE As System.Windows.Forms.Label
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents prcnt5 As Bunifu.Framework.UI.BunifuGauge
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnDONE As System.Windows.Forms.Button
End Class
