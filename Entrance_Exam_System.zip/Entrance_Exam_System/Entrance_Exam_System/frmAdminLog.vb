﻿Public Class frmAdminLog
    Public strAdmin As String = ""
    Private Sub btnStuLog_Click(sender As Object, e As EventArgs) Handles btnStuLog.Click
        AdminLog(strAdmin)
    End Sub
End Class