﻿Public Class frmStuLogin
    Public strStudent As String = ""
 

    Private Sub btnStuLog_Click(sender As Object, e As EventArgs) Handles btnStuLog.Click
        LoginUps(strStudent)
    End Sub

    Private Sub txtStuPass_TextChanged(sender As Object, e As EventArgs) Handles txtStuPass.TextChanged

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs)

    End Sub



End Class