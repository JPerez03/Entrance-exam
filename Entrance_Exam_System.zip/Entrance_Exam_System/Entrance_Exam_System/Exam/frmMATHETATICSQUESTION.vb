﻿Public Class frmMATHETATICSQUESTION
    Dim dateshow As Boolean = False
    Private Sub CloseChildForms()
        For Each frm As Form In Me.MdiChildren
            If frm.Name = "frmHome" Then
            Else
                frm.Close()
            End If
        Next
    End Sub
    Private Sub ToolStripStatusLabel1_Click(sender As Object, e As EventArgs) Handles ToolStripStatusLabel1.Click
        If dateshow = False Then
            MonthCalendar1.Visible = True
            dateshow = True
        Else
            MonthCalendar1.Visible = False
            dateshow = False
        End If
    End Sub
    Private Sub frmMATHETATICSQUESTION_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolStripStatusLabel1.Text = DateTime.Today.ToLongDateString()
    End Sub

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        CloseChildForms()
        frmMATH1.MdiParent = Me
        frmMATH1.Show()
        btnStart.Enabled = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ToolStripStatusLabel2.Text = DateTime.Now.ToLongTimeString()
    End Sub

    Private Sub btnDone_Click(sender As Object, e As EventArgs) Handles btnDone.Click
        frmExamStu.Show()
        Me.Hide()
    End Sub
End Class