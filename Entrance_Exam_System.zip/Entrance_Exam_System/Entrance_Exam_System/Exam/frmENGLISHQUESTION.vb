﻿Public Class frmENGLISHQUESTION
    Dim dateshow As Boolean = False
    Private Sub CloseChildForms()
        For Each frm As Form In Me.MdiChildren
            If frm.Name = "frmHome" Then
            Else
                frm.Close()
            End If
        Next
    End Sub
    Private Sub ToolStripStatusLabel1_Click(sender As Object, e As EventArgs) Handles ToolStripStatusLabel1.Click
        If dateshow = False Then
            MonthCalendar1.Visible = True
            dateshow = True
        Else
            MonthCalendar1.Visible = False
            dateshow = False
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ToolStripStatusLabel2.Text = DateTime.Now.ToLongTimeString()
    End Sub

    Private Sub frmENGLISHQUESTION_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolStripStatusLabel1.Text = DateTime.Today.ToLongDateString()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnStart.Click

        CloseChildForms()
        frmENG1.MdiParent = Me
        frmENG1.Show()
        btnStart.Enabled = False
    End Sub

    Private Sub btnDone_Click(sender As Object, e As EventArgs) Handles btnDone.Click
        ' If frmENG1.Panel3.Contains() And frmENG2.Panel3.Contains(rad1) And frmENG3.Panel3.Contains(rad1) And frmENG4.Panel3.Contains(rad1) And Panel3.Contains(rad1) Then
        'Dim tot As Integer = frmENG1.Panel3.Contains(rad1) + frmENG2.Panel3.Contains(rad1) + frmENG3.Panel3.Contains(rad1) + frmENG4.Panel3.Contains(rad1) + Panel3.Contains(rad1)
        ' frmExamStu.lblENGEXAM.Text = tot
        ' End If
        If frmENG1.rad1.Checked And frmENG2.rad1.Checked And frmENG3.rad1.Checked And frmENG4.rad1.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad1.Checked And frmENG3.rad1.Checked And frmENG4.rad1.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad1.Checked And frmENG3.rad1.Checked And frmENG4.rad1.Checked And frmENG5.rad3.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad3.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad1.Checked And frmENG3.rad1.Checked And frmENG4.rad1.Checked And frmENG5.rad4.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad4.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad1.Checked And frmENG3.rad1.Checked And frmENG4.rad2.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad1.Checked And frmENG3.rad1.Checked And frmENG4.rad3.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad3.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad1.Checked And frmENG3.rad1.Checked And frmENG4.rad4.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad4.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad1.Checked And frmENG3.rad2.Checked And frmENG4.rad1.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad1.Checked And frmENG3.rad3.Checked And frmENG4.rad1.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad3.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad1.Checked And frmENG3.rad4.Checked And frmENG4.rad1.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad4.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad2.Checked And frmENG3.rad1.Checked And frmENG4.rad1.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad3.Checked And frmENG3.rad1.Checked And frmENG4.rad1.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad3.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad4.Checked And frmENG3.rad1.Checked And frmENG4.rad1.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad4.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad1.Checked And frmENG3.rad1.Checked And frmENG4.rad1.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad3.Checked And frmENG2.rad1.Checked And frmENG3.rad1.Checked And frmENG4.rad1.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad3.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad4.Checked And frmENG2.rad1.Checked And frmENG3.rad1.Checked And frmENG4.rad1.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad4.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
            '-----------------------------'
        ElseIf frmENG1.rad2.Checked And frmENG2.rad2.Checked And frmENG3.rad2.Checked And frmENG4.rad2.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad2.Checked And frmENG3.rad2.Checked And frmENG4.rad2.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad2.Checked And frmENG3.rad2.Checked And frmENG4.rad2.Checked And frmENG5.rad3.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad3.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad2.Checked And frmENG3.rad2.Checked And frmENG4.rad2.Checked And frmENG5.rad4.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad4.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad2.Checked And frmENG3.rad2.Checked And frmENG4.rad1.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad2.Checked And frmENG3.rad2.Checked And frmENG4.rad3.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad3.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad2.Checked And frmENG3.rad2.Checked And frmENG4.rad4.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad4.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad2.Checked And frmENG3.rad1.Checked And frmENG4.rad2.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad1.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad2.Checked And frmENG3.rad3.Checked And frmENG4.rad2.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad3.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad2.Checked And frmENG3.rad4.Checked And frmENG4.rad2.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad4.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad1.Checked And frmENG3.rad2.Checked And frmENG4.rad2.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad1.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad3.Checked And frmENG3.rad2.Checked And frmENG4.rad2.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad3.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad2.Checked And frmENG2.rad4.Checked And frmENG3.rad2.Checked And frmENG4.rad2.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad2.Text) + Val(frmENG2.rad4.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad1.Checked And frmENG2.rad2.Checked And frmENG3.rad2.Checked And frmENG4.rad2.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad1.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad3.Checked And frmENG2.rad2.Checked And frmENG3.rad2.Checked And frmENG4.rad2.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad3.Text) + Val(frmENG2.rad2.Text) + Val(frmENG3.rad2.Text) + Val(frmENG4.rad2.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
            '-----------------------------------------------'
        ElseIf frmENG1.rad3.Checked And frmENG2.rad3.Checked And frmENG3.rad3.Checked And frmENG4.rad3.Checked And frmENG5.rad1.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad3.Text) + Val(frmENG2.rad3.Text) + Val(frmENG3.rad3.Text) + Val(frmENG4.rad3.Text) + Val(frmENG5.rad1.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad3.Checked And frmENG2.rad3.Checked And frmENG3.rad3.Checked And frmENG4.rad3.Checked And frmENG5.rad2.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad3.Text) + Val(frmENG2.rad3.Text) + Val(frmENG3.rad3.Text) + Val(frmENG4.rad3.Text) + Val(frmENG5.rad2.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad3.Checked And frmENG2.rad3.Checked And frmENG3.rad3.Checked And frmENG4.rad3.Checked And frmENG5.rad3.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad3.Text) + Val(frmENG2.rad3.Text) + Val(frmENG3.rad3.Text) + Val(frmENG4.rad3.Text) + Val(frmENG5.rad3.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad3.Checked And frmENG2.rad3.Checked And frmENG3.rad3.Checked And frmENG4.rad3.Checked And frmENG5.rad4.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad3.Text) + Val(frmENG2.rad3.Text) + Val(frmENG3.rad3.Text) + Val(frmENG4.rad3.Text) + Val(frmENG5.rad4.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad3.Checked And frmENG2.rad3.Checked And frmENG3.rad3.Checked And frmENG4.rad1.Checked And frmENG5.rad3.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad3.Text) + Val(frmENG2.rad3.Text) + Val(frmENG3.rad3.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad3.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        ElseIf frmENG1.rad3.Checked And frmENG2.rad3.Checked And frmENG3.rad3.Checked And frmENG4.rad1.Checked And frmENG5.rad3.Checked Then
            Dim totalres As Integer = Val(frmENG1.rad3.Text) + Val(frmENG2.rad3.Text) + Val(frmENG3.rad3.Text) + Val(frmENG4.rad1.Text) + Val(frmENG5.rad3.Text)
            frmExamStu.lblENGEXAM.Text = totalres
        
        End If


       
        frmExamStu.Show()
        Me.Hide()
    End Sub

  
End Class