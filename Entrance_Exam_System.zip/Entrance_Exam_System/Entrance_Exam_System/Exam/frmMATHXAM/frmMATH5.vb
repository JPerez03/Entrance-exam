﻿Public Class frmMATH5

End Class