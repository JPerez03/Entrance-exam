﻿Public Class frmENG5
    Private Sub CloseChildForms()
        For Each frm As Form In Me.MdiChildren
            If frm.Name = "frmHome" Then
            Else
                frm.Close()
            End If
        Next
    End Sub
    Private Sub frmENG5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        rad1.Text = ""
        rad2.Text = ""
        rad3.Text = ""
        rad4.Text = ""
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        frmENGLISHQUESTION.btnStart.Enabled = True
        frmExamStu.Show()
        frmENGLISHQUESTION.Hide()
        frmENG1.Hide()
        frmENG2.Hide()
        frmENG3.Hide()
        frmENG4.Hide()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        If frmENG1.btnNext.CanSelect And frmENG2.btnNext.CanSelect And frmENG3.btnNext.CanSelect And frmENG4.btnNext.CanSelect And btnNext.CanSelect Then
            frmENGLISHQUESTION.btnDone.Enabled = True
        End If
        CloseChildForms()

        frmExamStu.prcnt1.Value = 100
        Dim num1 As Integer = 20
        Dim num2 As Integer = 0
        Dim num3 As Integer = 0
        Dim num4 As Integer = 0
        rad1.Text = num1
        rad2.Text = num2
        rad3.Text = num3
        rad4.Text = num4
       
        ' If rad1.Checked And rad2.Checked And rad3.Checked Then
        'frmExamStu.lblENGEXAM.Text = "0"
        '   Else
        '   frmExamStu.lblENGEXAM.Text = "20"
        '   End If
        frmENGLISHQUESTION.Show()
        frmENG1.Hide()
        frmENG2.Hide()
        frmENG3.Hide()
        frmENG4.Hide()
        Me.Hide()
    End Sub
End Class