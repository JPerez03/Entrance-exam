﻿Public Class frmENG3
    Private Sub CloseChildForms()
        For Each frm As Form In Me.MdiChildren
            If frm.Name = "frmHome" Then
            Else
                frm.Close()
            End If
        Next
    End Sub
    Private Sub frmENG3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        rad1.Text = ""
        rad2.Text = ""
        rad3.Text = ""
        rad4.Text = ""
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        frmENGLISHQUESTION.btnStart.Enabled = True
        frmExamStu.Show()
        frmENGLISHQUESTION.Hide()
        frmENG1.Hide()
        frmENG2.Hide()
        Me.Hide()
        frmENG4.Hide()
        frmENG5.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        CloseChildForms()
        frmENG4.MdiParent = frmENGLISHQUESTION
        frmExamStu.prcnt1.Value = 60
        Dim num1 As Integer = 20
        Dim num2 As Integer = 0
        Dim num3 As Integer = 0
        Dim num4 As Integer = 0
        rad1.Text = num1
        rad2.Text = num2
        rad3.Text = num3
        rad4.Text = num4
        

        frmENG4.Show()
    End Sub
End Class