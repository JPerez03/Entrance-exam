﻿Public Class FillForm
    Public strSIGNUPCLIENT As String = ""
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnSaveInfo.Click
        SignUp(strSIGNUPCLIENT)
    End Sub

    Private Sub txtFN_TextChanged(sender As Object, e As EventArgs) Handles txtFN.TextChanged
        txtFN.MaxLength = 43

    End Sub

    Private Sub txtAdd_TextChanged(sender As Object, e As EventArgs) Handles txtAdd.TextChanged
        txtAdd.MaxLength = 43
    End Sub

    Private Sub txtLN_TextChanged(sender As Object, e As EventArgs) Handles txtLN.TextChanged

    End Sub

    Private Sub txtUser_TextChanged(sender As Object, e As EventArgs) Handles txtUser.TextChanged
       
    End Sub

    Private Sub txtPass_TextChanged(sender As Object, e As EventArgs) Handles txtPass.TextChanged
        txtPass.MaxLength = 8


    End Sub

    Private Sub Label17_Click(sender As Object, e As EventArgs) Handles Label17.Click

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        frmStuDecision.Show()
        Me.Hide()

    End Sub

    Private Sub FillForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtlrn.Text = "1000000"
    End Sub
End Class